package Autointrucional_loja;
import java.awt.event.*;
import javax.swing.*;

	@SuppressWarnings("serial")
	public class LojaMain extends JFrame{
		
		JButton b,b1,b2,b3; 
		Cliente c = new Cliente();
		Compra f = new Compra();
		Estoque e = new Estoque();
		String entrada;
		int op,qtd = 0;
		double valor = 0,valorFinal=0,valorTotal=0;
		
		public LojaMain(){
			getContentPane().setLayout(null); 
			Handler objetolistener = new Handler();
			b = new JButton(); 
			b.setText("Comprar"); 
			b.setBounds(10,100,200,30);
			b.addActionListener(objetolistener);
			add(b); 
			b1 = new JButton(); 
			b1.setText("Confirmar Compra"); 
			b1.setBounds(10,150,200,30);
			b1.addActionListener(objetolistener);
			add(b1); 
			b2 = new JButton(); 
			b2.setText("Cadastrar-se"); 
			b2.setBounds(10,200,200,30);
			b2.addActionListener(objetolistener);
			add(b2);  
			b3 = new JButton(); 
			b3.setText("Fechar"); 
			b3.setBounds(10,250,200,30);
			b3.addActionListener(objetolistener);
			add(b3); 
			setBounds(600,200,240,400);
			setVisible(true);
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		}
		
		public static void main (String[]arg) {
			new LojaMain();
			
		}
	
		public class Handler implements ActionListener{	
		
			public void actionPerformed (ActionEvent event){
				if (event.getSource() == b) {
					
					entrada = JOptionPane.showInputDialog("Selecione o Item que deseja comprar"
							+ "\n\n1 - Camiseta"
							+ "\n2 - Camisas de Manga Longa"
							+ "\n3 - Regatas"
							+ "\n4 - Moletons"
							+ "\n5 - Corta Vento"
							+ "\n6 - Cal�as"
							+ "\n7 - Bermudas"
							+ "\n8 - Tenis"
							+ "\n9 - Acessorios\n\n");
					op = Integer.parseInt(entrada);
					switch(op) {
					case 1: 
						JOptionPane.showMessageDialog(null, "CAMISETAS");
						entrada = JOptionPane.showInputDialog("Escolha a CAMISETA"
								+ "\n\n1 - Camiseta NIKE casual"
								+ "\n2 - Camiseta NIKE SB"
								+ "\n3 - Camiseta NIKE AIR"
								+ "\n4 - Camiseta Estampa NIKE SB\n\n");
						op = Integer.parseInt(entrada);
						if(op==1) {
							valor = 99.00;
							e.setDescricao("Camiseta NIKE CASUAL");
						}
						if(op==2) {
							valor = 125.00;
							e.setDescricao("Camiseta NIKE SB");
						}
						if(op==3) {
							valor = 129.00;
							e.setDescricao("Camiseta NIKE AIR");
						}
						if(op==4) {
							valor = 119.80;
							e.setDescricao("Camiseta estampa NIKE SB");
						}
						entrada = JOptionPane.showInputDialog("Quantidade: ");
						qtd = Integer.parseInt(entrada);
						f.setQuantidade(qtd);
						valorTotal = valor*qtd;
						break;
					case 2:
						JOptionPane.showMessageDialog(null, "CAMISAS DE MANGA LONGA");
						entrada = JOptionPane.showInputDialog("Escolha uma CAMISA DE MANGA LONGA"
								+ "\n\n1 - Camisa manga longa NIKE casual"
								+ "\n2 - Camisa manga longa NIKE SB"
								+ "\n3 - Camisa manga longa NIKE AIR"
								+ "\n4 - Camisa manga longa Estampa NIKE SB\n\n");
						op = Integer.parseInt(entrada);
						if(op==1) {
							valor = 99.00;
							e.setDescricao("Camisa manga longa NIKE casual");
						}
						if(op==2) {
							valor = 125.00;
							e.setDescricao("Camisa manga longa NIKE SB");
						}
						if(op==3) {
							valor = 129.00;
							e.setDescricao("Camisa manga longa NIKE AIR");
						}
						if(op==4) {
							valor = 119.80;
							e.setDescricao("Camisa manga longa Estampa NIKE SB");
						}
						entrada = JOptionPane.showInputDialog("Quantidade: ");
						qtd = Integer.parseInt(entrada);
						f.setQuantidade(qtd);
						valorTotal = valor*qtd;
						break;
					case 3:
						JOptionPane.showMessageDialog(null, "REGATAS");
						entrada = JOptionPane.showInputDialog("Escolha uma REGATA"
								+ "\n\n1 - Regata NIKE casual"
								+ "\n2 - Regata NIKE SB"
								+ "\n3 - Regata NIKE AIR\n\n");
						op = Integer.parseInt(entrada);
						if(op==1) {
							valor = 99.00;
							e.setDescricao("Regata NIKE casual");
						}
						if(op==2) {
							valor = 78.00;
							e.setDescricao("Regata NIKE SB");
						}
						if(op==3) {
							valor = 67.00;
							e.setDescricao("Regata NIKE AIR");
						}
						entrada = JOptionPane.showInputDialog("Quantidade: ");
						qtd = Integer.parseInt(entrada);
						f.setQuantidade(qtd);
						valorTotal = valor*qtd;
						break;
					case 4:
						JOptionPane.showMessageDialog(null, "MOLETONS");
						entrada = JOptionPane.showInputDialog("Escolha um MOLETON"
								+ "\n\n1 - Moleton NIKE casual"
								+ "\n2 - Moleton NIKE SB"
								+ "\n3 - Moleton NIKE AIR"
								+ "\n4 - Moleton Estampa NIKE SB\n\n");
						op = Integer.parseInt(entrada);
						if(op==1) {
							valor = 245.00;
							e.setDescricao("Moleton NIKE casual");
						}
						if(op==2) {
							valor = 350.00;
							e.setDescricao("Moleton NIKE SB");
						}
						if(op==3) {
							valor = 330.00;
							e.setDescricao("Moleton NIKE AIR");
						}
						if(op==4) {
							valor = 298.80;
							e.setDescricao("Moleton Estampa NIKE SB");
						}
						entrada = JOptionPane.showInputDialog("Quantidade: ");
						qtd = Integer.parseInt(entrada);
						f.setQuantidade(qtd);
						valorTotal = valor*qtd;
						break;
					case 5:
						JOptionPane.showMessageDialog(null, "CORTA VENTO");
						entrada = JOptionPane.showInputDialog("Escolha um CORTA VENTO"
								+ "\n\n1 - Corta vento NIKE SB"
								+ "\n2 - Corta vento NIKE AIR\n\n");
						op = Integer.parseInt(entrada);
						if(op==1) {
							valor = 499.00;
							e.setDescricao("Corta vento NIKE SB");
						}
						if(op==2) {
							valor = 379.00;
							e.setDescricao("Corta vento NIKE AIR");
						}
						entrada = JOptionPane.showInputDialog("Quantidade: ");
						qtd = Integer.parseInt(entrada);
						f.setQuantidade(qtd);
						valorTotal = valor*qtd;
						break;
					case 6:
						JOptionPane.showMessageDialog(null, "CAL�AS");
						entrada = JOptionPane.showInputDialog("Escolha uma CAL�A"
								+ "\n\n1 - Cal�a Slim NIKE"
								+ "\n2 - Cal�a Shino NIKE\n\n");
						op = Integer.parseInt(entrada);
						if(op==1) {
							valor = 199.00;
							e.setDescricao("Cal�a Slim NIKE");
						}
						if(op==2) {
							valor = 219.00;
							e.setDescricao("Cal�a Shino NIKE");
						}
						entrada = JOptionPane.showInputDialog("Quantidade: ");
						qtd = Integer.parseInt(entrada);
						f.setQuantidade(qtd);
						valorTotal = valor*qtd;
						break;
					case 7:
						JOptionPane.showMessageDialog(null, "BERMUDAS");
						entrada = JOptionPane.showInputDialog("Escolha uma BERMUDA"
								+ "\n\n1 - Bermuda NIKE"
								+ "\n2 - Bermuda NIKE SB\n\n");
						op = Integer.parseInt(entrada);
						if(op==1) {
							valor = 120.00;
							e.setDescricao("Bermuda NIKE");
						}
						if(op==2) {
							valor = 125.00;
							e.setDescricao("Bermuda NIKE SB");
						}
						entrada = JOptionPane.showInputDialog("Quantidade: ");
						qtd = Integer.parseInt(entrada);
						f.setQuantidade(qtd);
						valorTotal = valor*qtd;
						break;
					case 8:
						JOptionPane.showMessageDialog(null, "TENIS");
						entrada = JOptionPane.showInputDialog("Escolha um TENIS"
								+ "\n\n1 - JORDAN 5"
								+ "\n2 - NIKE AIR MAX"
								+ "\n3 - NIJAH FREE"
								+ "\n4 - NIKE REVOLUTION 6\n\n");
						op = Integer.parseInt(entrada);
						if(op==1) {
							valor = 499.00;
							e.setDescricao("JORDAN 5");
						}
						if(op==2) {
							valor = 370.00;
							e.setDescricao("NIKE AIR MAX");
						}
						if(op==3) {
							valor = 520.00;
							e.setDescricao("NIJAH FREE");
						}
						if(op==4) {
							valor = 268.80;
							e.setDescricao("NIKE REVOLUTION 6");
						}
						entrada = JOptionPane.showInputDialog("Quantidade: ");
						qtd = Integer.parseInt(entrada);
						f.setQuantidade(qtd);
						valorTotal = valor*qtd;
						break;
					case 9:
						JOptionPane.showMessageDialog(null, "ACESSORIOS");
						entrada = JOptionPane.showInputDialog("Escolha um acessorio"
								+ "\n\n1 - Bone DADHAT NIKE"
								+ "\n2 - Touca NIKE SB"
								+ "\n3 - Shoulder Bag NIKE AIR\n\n");
						op = Integer.parseInt(entrada);
						if(op==1) {
							valor = 110.00;
							e.setDescricao("Bone DADHAT NIKE");
						}
						if(op==2) {
							valor = 345.00;
							e.setDescricao("Touca NIKE SB");
						}
						if(op==3) {
							valor = 250.00;
							e.setDescricao("Shoulder Bag NIKE AIR");
						}
						entrada = JOptionPane.showInputDialog("Quantidade: ");
						qtd = Integer.parseInt(entrada);
						f.setQuantidade(qtd);
						valorTotal = valor*qtd;
						break;
					}					
				}
				else if (event.getSource() == b1) {
					
					entrada = JOptionPane.showInputDialog("Selecione uma forma de pagamento"
							+ "\n\n1 - Debito"
							+ "\n2 - Credito"
							+ "\n3 - Dinheiro\n\n");
					op = Integer.parseInt(entrada);
					switch(op) {
					case 1:
						f.setPagamento("DEBITO");
						JOptionPane.showMessageDialog(null, "FORMA DE PAGAMENTO NO DEBITO");
						valorTotal = valor*qtd;
						JOptionPane.showMessageDialog(null, "FATURA DA COMPRA"
								+ "\n\nProduto: "+e.getDescricao().toUpperCase()+"\nValor do Produto: "+valor+
								"\nQuantidade: "+f.getQuantidade()+"\nForma de Pagamento: "+f.getPagamento()+"\nTotal da Fatura: "+valorTotal);
						do{
							f.setNumeroCartao(JOptionPane.showInputDialog("Numero do cart�o: "));
							if(f.getNumeroCartao().equals("")) {
								JOptionPane.showMessageDialog(null, "!!CAMPO OBRIGAT�RIO!!");
							}
							else if(f.getNumeroCartao().length()!=16) {
								JOptionPane.showMessageDialog(null, "!!NUMERO DE DIGITOS INCORRETO!!");
							}
						}while(f.getNumeroCartao().equals("")||f.getNumeroCartao().length()!=16);
						do{
							f.setDataValid(JOptionPane.showInputDialog("Data de Validade: "));;
							if(f.getDataValid().equals("")) {
								JOptionPane.showMessageDialog(null, "!!CAMPO OBRIGAT�RIO!!");
							}
							else if(f.getDataValid().length()>5||f.getDataValid().length()<5) {
								JOptionPane.showMessageDialog(null, "!!NUMERO DE DIGITOS INCORRETO!!");
							}
						}while(f.getDataValid().equals("")||f.getDataValid().length()>5||f.getDataValid().length()<5);
						do{
							f.setCvv(JOptionPane.showInputDialog("Codigo de Seguran�a (CVV): "));
							if(f.getCvv().equals("")) {
								JOptionPane.showMessageDialog(null, "!!CAMPO OBRIGAT�RIO!!");
							}
							else if(f.getCvv().length()!=3) {
								JOptionPane.showMessageDialog(null, "!!NUMERO DE DIGITOS INCORRETO!!");
							}
						}while(f.getCvv().equals("")||f.getCvv().length()!=3);
						valorTotal = valor*qtd;
						JOptionPane.showMessageDialog(null, "FATURA DA COMPRA"
								+ "\n\nProduto: "+e.getDescricao().toUpperCase()+"\nValor do Produto: "+valor+
								"\nQuantidade: "+f.getQuantidade()+"\nForma de Pagamento: "+f.getPagamento()+"\nTotal da Fatura: "+valorTotal);
						JOptionPane.showMessageDialog(null, "Aguarde, Verificando seu dados");
						JOptionPane.showMessageDialog(null, "Compra feita com sucesso!!");
						break;
					case 2:
						JOptionPane.showMessageDialog(null, "FORMA DE PAGAMENTO NO CREDITO");
						f.setPagamento("CREDITO");
						valorTotal=valor*qtd;
						JOptionPane.showMessageDialog(null, "FATURA DA COMPRA"
								+ "\n\nProduto: "+e.getDescricao().toUpperCase()+"\nValor do Produto: "+valor+
								"\nQuantidade: "+f.getQuantidade()+"\nForma de Pagamento: "+f.getPagamento()+"\nTotal da Fatura: "+valorTotal);
						entrada = JOptionPane.showInputDialog("Escolha de quantas vezes deseja pagar"
								+ "\n\n1 - AVISTA"
								+ "\n2 - 3x"
								+ "\n3 - 5x"
								+ "\n4 - 10x\n\n");
						op = Integer.parseInt(entrada);
						switch(op) {
						case 1:
							if(op==1) {
								f.setValorParcelas("AVISTA");
								valorFinal=valorTotal/1;
							}
						case 2:
							if(op==2) {
								f.setValorParcelas("3x");
								valorFinal=valorTotal/3;
							}
						case 3:
							if(op==3) {
								f.setValorParcelas("5x");
								valorFinal=valorTotal/5;
							}	
						case 4:
							if(op==4) {
								f.setValorParcelas("10x");
								valorFinal=valorTotal/10;
							}	
						}
						do{
							f.setNumeroCartao(JOptionPane.showInputDialog("Numero do cart�o: "));
							if(f.getNumeroCartao().equals("")) {
								JOptionPane.showMessageDialog(null, "!!CAMPO OBRIGAT�RIO!!");
							}
							else if(f.getNumeroCartao().length()!=16) {
								JOptionPane.showMessageDialog(null, "!!NUMERO DE DIGITOS INCORRETO!!");
							}
						}while(f.getNumeroCartao().equals("")||f.getNumeroCartao().length()!=16);
						do{
							f.setDataValid(JOptionPane.showInputDialog("Data de Validade: "));;
							if(f.getDataValid().equals("")) {
								JOptionPane.showMessageDialog(null, "!!CAMPO OBRIGAT�RIO!!");
							}
							else if(f.getDataValid().length()>5||f.getDataValid().length()<5) {
								JOptionPane.showMessageDialog(null, "!!NUMERO DE DIGITOS INCORRETO!!");
							}
						}while(f.getDataValid().equals("")||f.getDataValid().length()>5||f.getDataValid().length()<5);
						do{
							f.setCvv(JOptionPane.showInputDialog("Codigo de Seguran�a (CVV): "));
							if(f.getCvv().equals("")) {
								JOptionPane.showMessageDialog(null, "!!CAMPO OBRIGAT�RIO!!");
							}
							else if(f.getCvv().length()!=3) {
								JOptionPane.showMessageDialog(null, "!!NUMERO DE DIGITOS INCORRETO!!");
							}
						}while(f.getCvv().equals("")||f.getCvv().length()!=3);
						valorTotal=valor*qtd;
						JOptionPane.showMessageDialog(null, "FATURA DA COMPRA"
								+ "\n\nProduto: "+e.getDescricao().toUpperCase()+"\nValor do Produto: "+valor+
								"\nQuantidade: "+f.getQuantidade()+"\nForma de Pagamento: "+f.getPagamento()+"\nValor das Parcelas: "+
								f.getValorParcelas()+" "+valorFinal+"\nTotal da Fatura: "+valorTotal);
						JOptionPane.showMessageDialog(null, "Aguarde, Verificando seu dados");
						JOptionPane.showMessageDialog(null, "Compra feita com sucesso!!");
						break;
					case 3:
						JOptionPane.showMessageDialog(null, "FORMA DE PAGAMENTO NO DINHEIRO");
						if(op==3) {
							f.setPagamento("DINHEIRO");
							valorTotal=valor*qtd;
							JOptionPane.showMessageDialog(null, "FATURA DA COMPRA"
									+ "\n\nProduto: "+e.getDescricao().toUpperCase()+"\nValor do Produto: "+valor+
									"\nQuantidade: "+f.getQuantidade()+"\nForma de Pagamento: "+f.getPagamento()+"\nTotal da Fatura: "+valorTotal);
							JOptionPane.showMessageDialog(null, "Boleto Gerado com sucesso!! Confira o seu e-mail");
						}
						break;
					}
				}
				
				else if (event.getSource() == b2) {
					
					do {
						c.setNome(JOptionPane.showInputDialog("Nome Completo: "));
						if(c.getNome().equals("")) {
							JOptionPane.showMessageDialog(null, "!!CAMPO OBRIGAT�RIO!!");
						}
					}while(c.getNome().equals(""));
					do {
						c.setCpf(JOptionPane.showInputDialog("CPF: "));
						if(c.getCpf().equals("")) {
							JOptionPane.showMessageDialog(null, "!!CAMPO OBRIGAT�RIO!!");
						}
					}while(c.getCpf().equals(""));
					do {
						c.setEndere�o(JOptionPane.showInputDialog("Endere�o: "));
						if(c.getEndere�o().equals("")) {
							JOptionPane.showMessageDialog(null, "!!CAMPO OBRIGAT�RIO!!");
						}
					}while(c.getEndere�o().equals(""));
					do {
						c.setTelefone(JOptionPane.showInputDialog("Telefone: "));
						if(c.getTelefone().equals("")) {
							JOptionPane.showMessageDialog(null, "!!CAMPO OBRIGAT�RIO!!");
						}
					}while(c.getTelefone().equals(""));
					do {
						c.setEmail(JOptionPane.showInputDialog("E-mail: "));
						if(c.getEmail().equals("")) {
							JOptionPane.showMessageDialog(null, "!!CAMPO OBRIGAT�RIO!!");
						}
					}while(c.getEmail().equals(""));
					JOptionPane.showMessageDialog(null, "Nome: "+c.getNome().toUpperCase()+"\nCPF: "+c.getCpf()+"\nTelefone: "+c.getTelefone()+
							"\nEndere�o: "+c.getEndere�o().toUpperCase()+"\nE-mail: "+c.getEmail());
					JOptionPane.showMessageDialog(null, "!!CADASTRO FEITO COM SUCESSO!!");
				}
				
				else if (event.getSource() == b3) { 
					System.exit(0);
				}
			}
		}
	}
