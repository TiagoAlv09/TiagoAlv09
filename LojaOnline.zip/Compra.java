package Autointrucional_loja;
public class Compra extends Estoque{
	
	private int quantidade;
	private String pagamento;
	private String numeroCartao;
	private String cvv;
	private String dataValid;
	private String valorParcelas;
	
	public String getValorParcelas() {
		return valorParcelas;
	}
	public void setValorParcelas(String valorParcelas) {
		this.valorParcelas = valorParcelas;
	}
	public String getNumeroCartao() {
		return numeroCartao;
	}
	public void setNumeroCartao(String numeroCartao) {
		this.numeroCartao = numeroCartao;
	}
	public String getCvv() {
		return cvv;
	}
	public void setCvv(String cvv) {
		this.cvv = cvv;
	}
	public String getDataValid() {
		return dataValid;
	}
	public void setDataValid(String dataValid) {
		this.dataValid = dataValid;
	}
	public int getQuantidade() {
		return quantidade;
	}
	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}
	public String getPagamento() {
		return pagamento;
	}
	public void setPagamento(String pagamento) {
		this.pagamento = pagamento;
	}

}

