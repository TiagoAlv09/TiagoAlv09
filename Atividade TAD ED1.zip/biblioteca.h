typedef struct {
    char nome[50];
    int notaFinal;
    char situacao;
}Aluno;
 
typedef Aluno* AlunoPtr;

int validarNumero();
void cadastrarNome(char *nome);
void cadastrarNota(Aluno *aluno);
void cadastrarSituacao(int nota, char *situacao);
void cadastrarAlunos(AlunoPtr alunos, int tamanho);
void exibirAlunos(AlunoPtr alunos, int tamanho, float *media);
void exibirAlunosPorSituacao(AlunoPtr alunos, int tamanho, char situacao);
void menu();