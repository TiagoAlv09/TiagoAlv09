#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "biblioteca.h"
 
//ex 3
void menu(){
    char op;
    AlunoPtr alunos;
    int tamanho=0;
    float media=0.0;
    do{
        printf("\n                 MENU\n");
        printf("Selecione uma Opção:\nA-Preencher dados\nB-Exibir\nC-Exibir por Situação\nD-Finalizar\n");
        scanf(" %c",&op);
        switch(op){
            case 'a':
                printf("Quantos alunos deseja cadastrar? ");
                tamanho = validarNumero();
                alunos = (AlunoPtr)malloc(tamanho*sizeof(Aluno));
                cadastrarAlunos(alunos,tamanho);
                break;
            case 'b':
                exibirAlunos(alunos,tamanho,&media);
                printf("Média das notas: %.2f\n",media);
                break;
            case 'c': 
                char situacao;
                printf("Deseja ver os alunos A-Aprovados ou R-Reprovados? (A/R): ");
                scanf(" %c",&situacao);
                exibirAlunosPorSituacao(alunos,tamanho,situacao);
                break;
            case 'd':
                printf("Finalizando o programa.\n");
                return;
            default:
                printf("Opção inválida! Tente novamente.\n");
                break;
        }
    }while(op!='d');
}
 
//ex 4
int validarNumero(){
    int num;
    do{
        printf("Digite um número de 1 a 10: ");
        scanf("%d", &num);
        if(num<1||num>10){
            printf("\nDigite novamente\n");
        }
    }while(num<1||num>10);
    return num;
}
//ex 5
void cadastrarNome(char *nome){
    printf("Digite o nome do aluno: ");
    scanf(" %[^\n]s", nome);
}
 
void cadastrarNota(Aluno *aluno){
    do{
        printf("Digite a nota final (0-100): ");
        scanf("%d",&aluno->notaFinal);
        if(aluno->notaFinal<0||aluno->notaFinal>100){
            printf("\nNota deve ser entre 0 e 100\n");
        }
    }while(aluno->notaFinal<0||aluno->notaFinal>100);
}
 
void cadastrarSituacao(int nota,char *situação){
    if(nota<60){
        *situação = 'R';
    }else{
        *situação = 'A';
    }
}
 
//ex 6
void cadastrarAlunos(AlunoPtr alunos,int tamanho){
    for (int i=0; i<tamanho; i++){
        cadastrarNome(alunos[i].nome);
        cadastrarNota(&alunos[i]);
        cadastrarSituacao(alunos[i].notaFinal, &alunos[i].situacao);
    }
}
 
//ex 7
void exibirAlunos(AlunoPtr alunos,int tamanho,float *media){
    if (tamanho==0){
        printf("Não existem alunos cadastrados.\n");
        return;
    }
    float somaNotas=0;
    printf("Alunos cadastrados:\n");
    for (int i=0;i<tamanho;i++) {
        printf("Nome: %s, Nota: %d, Situação: %c\n",alunos[i].nome,alunos[i].notaFinal,alunos[i].situacao);
        somaNotas += alunos[i].notaFinal;
    }
    *media = somaNotas/tamanho;
}
 
//ex 8
void exibirAlunosPorSituacao(AlunoPtr alunos,int tamanho,char situacao){
    int encontrou=0;
    for (int i=0;i<tamanho;i++){
        if (alunos[i].situacao == situacao){
            printf("Nome: %s, Nota: %d\n",alunos[i].nome,alunos[i].notaFinal);
            encontrou=1;
        }
    }
    if (!encontrou) {
        printf("Não existem alunos na situação %c.\n",situacao);
    }
}